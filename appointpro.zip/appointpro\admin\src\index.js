import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('appointpro-admin-root');
    if (container) {
        const root = createRoot(container);
        root.render(<App />);
    }
});
